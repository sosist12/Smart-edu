import random

random_number = random.randint(1, 100)

print(random_number)